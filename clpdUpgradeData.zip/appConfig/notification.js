module.exports = {
    "id": "notification",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-06-20",
        "name": "通知提示策略",
        "fileName": "client/notification.js",
        "inited": true
    },
    "content": {
        "runtime": {
            "disabled": false
        },
        "tray": {
            "title": "电子文件密级标志管理系统",
            "eventName": "tray::notify::message",
            "delay": 1000
        },
        "intergration": {
            "pipeName": "integratedPipe"
        },
        "notification": {
            "explorer-plugin": {
                "name": "资源管理器",
                "EXPLOREPLUGIN": {
                    "name": "右键菜单",
                    "codeName": "command",
                    "command": {
                        "0": {
                            "name": "预定密",
                            "requireLogin": true
                        },
                        "1": {
                            "name": "标志编辑",
                            "requireLogin": true
                        },
                        "2": {
                            "name": "标志查看",
                            "requireLogin": true
                        },
                        "3": {
                            "name": "正式定密",
                            "requireLogin": true
                        },
                        "4": {
                            "name": "文件签发",
                            "requireLogin": true
                        },
                        "5": {
                            "name": "密级变更",
                            "requireLogin": true
                        },
                        "6": {
                            "name": "文件解密",
                            "requireLogin": true
                        },
                        "7": {
                            "name": "标志解除",
                            "requireLogin": true
                        },
                        "10": {
                            "name": "文件签入",
                            "requireLogin": true
                        },
                        "11": {
                            "name": "文件签出",
                            "requireLogin": true
                        }
                    }
                }
            },
            "notify-plugin": {
                "name": "通知消息",
                "FILEPREVILEGE": {
                    "name": "文件权限",
                    "codeName": "code",
                    "command": {
                        "5": {
                            "name": "密级变更",
                            "requireLogin": true
                        },
                        "6": {
                            "name": "文件解密",
                            "requireLogin": true
                        },
                        "7": {
                            "name": "标志解除",
                            "requireLogin": true
                        },
                        "10": {
                            "name": "文件签入",
                            "requireLogin": true
                        },
                        "11": {
                            "name": "文件签出",
                            "requireLogin": true
                        },
                        "12": {
                            "name": "标志查看",
                            "requireLogin": true
                        },
                        "13": {
                            "name": "正式定密",
                            "requireLogin": true
                        },
                        "20": {
                            "name": "文件签发",
                            "requireLogin": true
                        }
                    }
                }
            }
        },
        "openTamperFile": {
            "value": 180000,
            "desc": "打开篡改文件后value毫秒后通知"
        },
        "labelFileMontior": {
            "value": 200,
            "desc": "动态监控先收集11、12、14、15、17消息value秒后在执行"
        }
    }
};