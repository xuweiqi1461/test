module.exports = {
    "id": "timedTask",
    "meta": {
        "version": "7.0",
        "createdTime": "2017-07-06",
        "name": "定时任务配置",
        "fileName": "client/timedTask.js",
        "inited": true
    },
    "content": {
        "logEnabledState": {
            "desc": "日志备份的启用状态",
            "checked": true
        },
        "logInterval": {
            "desc": "执行间隔",
            "value": "1",
            "time": "18:30:00"
        },
        "logTransferPosition": {
            "desc": "日志备份目录",
            "value": ""
        },
        "dataEnabledState": {
            "desc": "启用状态",
            "checked": true
        },
        "dataInterval": {
            "desc": "执行间隔",
            "value": "1",
            "time": "18:30:00"
        },
        "dataList": {
            "desc": "数据备份目录",
            "value": ""
        },
        "sqlList": {
            "desc": "数据库安装路径",
            "value": "/opt/MJBZGL/MJBZGL/WLH/CLIENT/app/GNMOD2/bin"
        },
        "showsyncData": {
            "show": false
        },
        "syncDataLevel": {
            "desc": "同步用户默认密级",
            "value": "20"
        },
        "syncDataServer": {
            "desc": "同步地址",
            "value": ""
        },
        "syncDataCycle": {
            "desc": "同步周期",
            "value": ""
        },
        "generatorChallengeUrl": {
            "desc": "获取随机数接口",
            "value": ""
        },
        "getsignandtokenreqUrl": {
            "desc": "获取票据接口",
            "value": ""
        },
        "verifyIdentityUrl": {
            "desc": "获取用户标识接口",
            "value": ""
        },
        "appserverid": {
            "desc": "服务身份码",
            "value": ""
        },
        "sync618": {
            "enabled": false,
            "deptUrl": "",
            "userUrl": "",
            "circle": ""
        }
    }
};