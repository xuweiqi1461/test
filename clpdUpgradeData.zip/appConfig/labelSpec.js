module.exports = {
    "id": "labelSpec",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-06-20",
        "name": "密级标志规格",
        "fileName": "client/labelSpec.js",
        "inited": true
    },
    "content": {
        "labelSpecId": 1,
        "labelSpecVersion": 1,
        "algoSpecId": 1,
        "algoSpecVersion": 1,
        "level": 0,
        "fileContentId": "",
        "fileUniqueId": "",
        "fileAssetId": "",
        "duration": {
            "classifiedTime": "",
            "period": "",
            "declassifiedTime": "",
            "condition": ""
        },
        "status": 0,
        "drafter": {
            "id": "",
            "name": ""
        },
        "authority": {
            "id": "",
            "name": ""
        },
        "issuer": {
            "id": "",
            "name": ""
        },
        "organs": [],
        "scope": {
            "description": "",
            "staffs": [],
            "groups": [],
            "units": []
        },
        "basises": {
            "type": 0,
            "description": "",
            "normalItems": [],
            "derivedItems": []
        },
        "histories": [],
        "keys": [],
        "permissions": {
            "write": 1,
            "contentCopy": 1,
            "fileCopy": 1,
            "contentPaste": 1,
            "print": 1,
            "printMark": 1,
            "screenCapture": 1,
            "rename": 1,
            "distribution": 1
        },
        "extension": {
            "operationControl": "0-0-0"
        }
    }
};