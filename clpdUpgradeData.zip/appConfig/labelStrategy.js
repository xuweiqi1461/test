module.exports = {
    "id": "labelStrategy",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-07-12",
        "name": "加标模式",
        "fileName": "client/labelStrategy.js",
        "inited": true
    },
    "content": {
        "switch": {
            "disabled": false,
            "items": [
                {
                    "id": "0",
                    "value": "手动",
                    "checked": true
                },
                {
                    "id": "1",
                    "value": "自动",
                    "checked": false,
                    "items": {
                        "id": "2",
                        "value": "是否强制:(checked:true,allowToClose:false)开启强标,(checked:true,allowToClose:true)提醒",
                        "checked": true,
                        "allowToClose": true
                    }
                },
                {
                    "id": "3",
                    "value": "直接",
                    "checked": false
                }
            ]
        }
    },
    "name": "加标模式"
};