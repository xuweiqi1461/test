module.exports = {
    "id": "clpdClient",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-06-20",
        "name": "客户端运行时策略",
        "fileName": "client/clpdClient.js",
        "inited": true
    },
    "content": {
        "runtime": {
            "autoLogin": true,
            "showAfterLogin": false
        },
        "workflow": {
            "removeLabelApply": true
        },
        "upstream": {
            "ipAddress": false,
            "port": false,
            "protocol": false,
            "ssl": {
                "ca": "product/client-config/ssl/cacert.crt",
                "client": "product/client-config/ssl/client.crt",
                "key": "product/client-config/ssl/client.key"
            }
        },
        "uninstall": {
            "flag": false,
            "desc": "客户端卸载时是否使用卸载码"
        },
        "forceLogin": {
            "flag": true,
            "desc": "是否要求强制登录"
        },
        "autoShowFrame": {
            "flag": false,
            "desc": "界面自启动"
        },
        "force50": {
            "flag": true,
            "desc": "强制预定密功能是否启用"
        },
        "merge14": {
            "flag": true,
            "desc": "文档合并自动加标功能是否启用"
        },
        "saveAs": {
            "flag": true,
            "desc": "文档另存为自动加标功能是否启用"
        },
        "conversion": {
            "flag": true,
            "desc": "格式自动转换自动加标功能是否启用"
        },
        "contentControl": {
            "flag": true,
            "desc": "内容管控功能是否启用"
        },
        "screenCapture": {
            "flag": true,
            "desc": "截屏管控功能是否启用"
        },
        "upgradeFlag": {
            "flag": true,
            "desc": "是否显示升级相关功能"
        },
        "uninstallFlag": {
            "flag": true,
            "desc": "是否显示卸载相关功能"
        },
        "upgradeData": {
            "flag": false,
            "desc": "服务器升级数据"
        },
        "isShowControl": {
            "flag": true,
            "desc": "管控属性页面内容复制,粘贴管控是否显示"
        },
        "protocol": {
            "flag": "",
            "desc": "修改通信协议(http,https),仅支持单机版修改,修改后需要重启计算机"
        },
        "isNotSelectOwn": {
            "flag": false,
            "desc": "申请时不可选择自己为审批人"
        }
    },
    "name": "客户端运行时策略"
};