module.exports = {
    "id": "normalStrategy",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-07-12",
        "name": "定密依据",
        "fileName": "client/normalStrategy.js",
        "inited": true
    },
    "content": {
        "fileType_M": {
            "value": "明确事项",
            "checked": true
        },
        "fileType": {
            "value": "已定密事项",
            "checked": true,
            "items": [
                {
                    "id": "0",
                    "value": "选取正式定密文件",
                    "checked": true
                },
                {
                    "id": "1",
                    "value": "录入正式定密文件",
                    "checked": true
                },
                {
                    "id": "2",
                    "value": "外来文件",
                    "checked": true
                }
            ]
        },
        "fileType_B": {
            "value": "不明确事项",
            "checked": true
        },
        "fileType_W": {
            "value": "无权定密",
            "checked": true
        }
    }
};