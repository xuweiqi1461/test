module.exports = {
    "id": "explorer",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-06-20",
        "name": "资源管理器右键菜单",
        "fileName": "client/explorer.js",
        "inited": true
    },
    "content": {
        "variables": {
            "classified": false,
            "desc": "明文是否可以正式定密"
        },
        "limitSecret": {
            "limitSecretLevel": true,
            "desc": "限制低密级用户打开高密级文件功能是否启用,false表示不限制；true表示限制"
        },
        "theScope": {
            "controlPolicy": true,
            "desc": "限制知悉范围外的用户打开文件的功能是否启用"
        },
        "edit": {
            "isNonPreclassifiedEdit": true,
            "desc": "签发文件是否可编辑"
        },
        "centralizedControl": {
            "flag": false,
            "desc": "根据文档集中管控功能是否启用,显示或隐藏右键菜单"
        },
        "secretType": 1,
        "warrantMode": 2,
        "explorerMenu": [
            {
                "name": "电子文件密级标志管理系统",
                "command": "0",
                "isPop": true,
                "classifiedPersonOption": "0",
                "enableGrayedOption": false,
                "isGrayed": {
                    "userLevel": [],
                    "leve": [],
                    "status": [],
                    "transferFileStatus": "1"
                },
                "submenu": [
                    {
                        "name": "预定密",
                        "command": "0",
                        "isPop": false,
                        "classifiedPersonOption": "0",
                        "enableGrayedOption": true,
                        "isGrayed": {
                            "userLevel": [],
                            "level": [],
                            "status": [
                                "50",
                                "80",
                                "110",
                                "140",
                                "170"
                            ],
                            "transferFileStatus": "2"
                        }
                    },
                    {
                        "name": "修改密级标志",
                        "command": "1",
                        "isPop": false,
                        "classifiedPersonOption": "1",
                        "enableGrayedOption": true,
                        "isGrayed": {
                            "userLevel": [],
                            "level": [
                                "0"
                            ],
                            "status": [
                                "80",
                                "110",
                                "140",
                                "170"
                            ],
                            "transferFileStatus": "2"
                        }
                    },
                    {
                        "name": "查看密级标志",
                        "command": "2",
                        "isPop": false,
                        "classifiedPersonOption": "0",
                        "enableGrayedOption": true,
                        "isGrayed": {
                            "userLevel": [],
                            "level": [
                                "0"
                            ],
                            "status": [],
                            "transferFileStatus": "2"
                        }
                    },
                    {
                        "name": "定密申请",
                        "command": "0",
                        "isPop": true,
                        "classifiedPersonOption": "0",
                        "enableGrayedOption": false,
                        "isGrayed": {
                            "userLevel": [],
                            "level": [],
                            "status": [],
                            "transferFileStatus": "1"
                        },
                        "submenu": []
                    },
                    {
                        "name": "文件备份",
                        "command": "8",
                        "isPop": false,
                        "classifiedPersonOption": "0",
                        "enableGrayedOption": true,
                        "isGrayed": {
                            "userLevel": [
                                "20",
                                "21"
                            ],
                            "level": [
                                "0"
                            ],
                            "status": [],
                            "transferFileStatus": "2"
                        }
                    },
                    {
                        "name": "文件恢复",
                        "command": "9",
                        "isPop": false,
                        "classifiedPersonOption": "0",
                        "enableGrayedOption": true,
                        "isGrayed": {
                            "userLevel": [
                                "20",
                                "21"
                            ],
                            "level": [
                                "0"
                            ],
                            "status": [],
                            "transferFileStatus": "2"
                        }
                    }
                ]
            }
        ],
        "command4": {
            "name": "国家秘密签发申请",
            "command": "4",
            "isPop": false,
            "classifiedPersonOption": "0",
            "enableGrayedOption": true,
            "isGrayed": {
                "userLevel": [
                    "20",
                    "21"
                ],
                "level": [
                    "0"
                ],
                "status": [
                    "50",
                    "170"
                ],
                "transferFileStatus": "2"
            }
        },
        "command3": {
            "name": "国家秘密确定申请",
            "command": "3",
            "isPop": false,
            "classifiedPersonOption": "0",
            "enableGrayedOption": true,
            "grayedOn": {
                "%classified%": 1
            },
            "isGrayed": {
                "userLevel": [
                    "20",
                    "21"
                ],
                "level": [
                    "0"
                ],
                "status": [
                    "80",
                    "110",
                    "140",
                    "170"
                ],
                "transferFileStatus": "2"
            }
        },
        "command7": {
            "name": "去除密级标志申请",
            "command": "7",
            "isPop": false,
            "classifiedPersonOption": "0",
            "enableGrayedOption": false,
            "isGrayed": {
                "userLevel": [],
                "level": [
                    "0"
                ],
                "status": [],
                "transferFileStatus": "2"
            }
        },
        "command10": {
            "name": "文件签入",
            "command": "10",
            "isPop": false,
            "classifiedPersonOption": "0",
            "enableGrayedOption": true,
            "isGrayed": {
                "userLevel": [],
                "level": [
                    "0"
                ],
                "status": [
                    "50",
                    "80",
                    "110",
                    "140",
                    "170"
                ],
                "transferFileStatus": "1"
            }
        },
        "command11": {
            "name": "文件签出",
            "command": "11",
            "isPop": false,
            "classifiedPersonOption": "0",
            "enableGrayedOption": true,
            "isGrayed": {
                "userLevel": [],
                "level": [
                    "0"
                ],
                "status": [],
                "transferFileStatus": "2"
            }
        },
        "command13": {
            "name": "文件篡改校验",
            "command": "13",
            "isPop": false,
            "classifiedPersonOption": "0",
            "enableGrayedOption": true,
            "isGrayed": {
                "userLevel": [],
                "level": [
                    "0"
                ],
                "status": [],
                "transferFileStatus": "2"
            }
        },
        "command5": {
            "name": "国家秘密变更申请",
            "command": "5",
            "isPop": false,
            "classifiedPersonOption": "0",
            "enableGrayedOption": true,
            "isGrayed": {
                "userLevel": [
                    "20",
                    "21"
                ],
                "level": [
                    "0"
                ],
                "status": [
                    "50",
                    "80",
                    "170"
                ],
                "transferFileStatus": "2"
            }
        },
        "command6": {
            "name": "国家秘密解除申请",
            "command": "6",
            "isPop": false,
            "classifiedPersonOption": "0",
            "enableGrayedOption": true,
            "isGrayed": {
                "userLevel": [
                    "20",
                    "21"
                ],
                "level": [
                    "0"
                ],
                "status": [
                    "50",
                    "170"
                ],
                "transferFileStatus": "2"
            }
        },
        "command8": {
            "name": "文件备份",
            "command": "8",
            "isPop": false,
            "classifiedPersonOption": "0",
            "enableGrayedOption": true,
            "isGrayed": {
                "userLevel": [
                    "20",
                    "21"
                ],
                "level": [
                    "0"
                ],
                "status": [],
                "transferFileStatus": "2"
            }
        },
        "command9": {
            "name": "文件恢复",
            "command": "9",
            "isPop": false,
            "classifiedPersonOption": "0",
            "enableGrayedOption": true,
            "isGrayed": {
                "userLevel": [
                    "20",
                    "21"
                ],
                "level": [
                    "0"
                ],
                "status": [],
                "transferFileStatus": "2"
            }
        },
        "commandnames": {
            "secretType1": {
                "command3": "国家秘密确定申请",
                "command4": "国家秘密签发申请",
                "command5": "国家秘密变更申请",
                "command6": "国家秘密解除申请",
                "command33": "国家秘密确定待办",
                "command44": "国家秘密签发待办",
                "command55": "国家秘密变更待办",
                "command66": "国家秘密解除待办",
                "command333": "国家秘密确定",
                "command444": "国家秘密签发",
                "command555": "国家秘密变更",
                "command666": "国家秘密解除"
            },
            "secretType2": {
                "command3": "商业秘密确定申请",
                "command4": "商业秘密签发申请",
                "command5": "商业秘密变更申请",
                "command6": "商业秘密解除申请",
                "command33": "商业秘密确定待办",
                "command44": "商业秘密签发待办",
                "command55": "商业秘密变更待办",
                "command66": "商业秘密解除待办",
                "command333": "商业秘密确定",
                "command444": "商业秘密签发",
                "command555": "商业秘密变更",
                "command666": "商业秘密解除"
            },
            "secretType3": {
                "command3": "正式定密申请",
                "command4": "文件签发申请",
                "command5": "密级变更申请",
                "command6": "密级解除申请",
                "command33": "正式定密待办",
                "command44": "文件签发待办",
                "command55": "密级变更待办",
                "command66": "密级解除待办",
                "command333": "正式定密",
                "command444": "文件签发",
                "command555": "密级变更",
                "command666": "密级解除"
            }
        }
    }
};