module.exports = {
    "id": "fileView",
    "meta": {
        "version": "1.0",
        "createdTime": "2022-06-28",
        "name": "越级查看配置",
        "fileName": "client/fileView.js",
        "inited": true
    },
    "content": {
        "runtime": {
            "enabled": false
        },
        "type": "1",
        "expirationTime": "1800",
        "configurations": {
            "0": [],
            "1": []
        }
    }
};