module.exports = {
    "id": "skinManagement",
    "meta": {
        "version": "1.0",
        "createdTime": "2018-09-25",
        "name": "皮肤管理",
        "fileName": "client/skinManagement.js",
        "inited": true
    },
    "content": {
        "skins": [
            {
                "id": "orange",
                "name": "默认",
                "checked": true
            },
            {
                "id": "grey",
                "name": "浅灰色",
                "checked": false
            },
            {
                "id": "black",
                "name": "警告黑色",
                "checked": false
            },
            {
                "id": "blue",
                "name": "商务蓝",
                "checked": false
            }
        ]
    }
};