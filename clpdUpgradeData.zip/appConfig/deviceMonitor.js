module.exports = {
    "id": "deviceMonitor",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-06-20",
        "name": "设备监控",
        "fileName": "client/deviceMonitor.js",
        "inited": true
    },
    "content": {
        "runtime": {
            "disabled": false
        }
    }
};