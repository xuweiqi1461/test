module.exports = {
    "id": "loginTime",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-09-25",
        "name": "超时锁定",
        "fileName": "client/loginTime.js",
        "inited": true
    },
    "content": {
        "desc": "超时锁定是否开启与不操作后n分钟锁定",
        "flag": true,
        "timeOut": "3"
    }
};