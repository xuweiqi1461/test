module.exports = {
    "id": "workFlow",
    "meta": {
        "version": "1.0",
        "createdTime": "2019-06-12",
        "name": "申请审批",
        "fileName": "client/workFlow.js",
        "inited": true
    },
    "content": {
        "readFile": {
            "flag": true,
            "desc": "审核、审批时是否强制查看文档"
        },
        "modifyFile": {
            "flag": false,
            "desc": "审核、审批过程中是否支持文档内容修改（不包括签发审批流程）"
        },
        "modifyIssueFile": {
            "flag": true,
            "desc": "签发时文档是否可修改"
        },
        "issueRepeatedly": {
            "flag": false,
            "desc": "是否允许重复签发"
        },
        "endWorkflow": {
            "flag": false,
            "desc": "安全管理员是否终止用户提交的流程"
        }
    }
};