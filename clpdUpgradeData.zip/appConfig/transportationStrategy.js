module.exports = {
    "id": "transportationStrategy",
    "meta": {
        "version": "1.0",
        "createdTime": "2018-06-25",
        "name": "运管设备",
        "fileName": "client/transportationStrategy.js",
        "inited": true
    },
    "content": {
        "runtime": {
            "disabled": true
        },
        "exchangeService": {
            "serverIp": "",
            "serverPort": "1235",
            "verificationCode": ""
        },
        "informationSyncService": {
            "serverIp": "",
            "serverPort": "8080",
            "verificationCode": ""
        },
        "middlewareActService": {
            "serverIp": "",
            "serverPort": "8989"
        }
    }
};