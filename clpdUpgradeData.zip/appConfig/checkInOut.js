module.exports = {
    "id": "checkInOut",
    "meta": {
        "version": "1.0",
        "createdTime": "2019-06-12",
        "name": "签入签出策略",
        "fileName": "client/checkInOut.js",
        "inited": true
    },
    "content": {
        "checkHide": {
            "flag": false,
            "desc": "运管系统是否启用"
        }
    }
};