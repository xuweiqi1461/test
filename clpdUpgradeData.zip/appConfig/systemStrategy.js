module.exports = {
    "id": "systemStrategy",
    "meta": {
        "version": "1.0",
        "createdTime": "2019-06-12",
        "name": "系统配置策略",
        "fileName": "client/systemStrategy.js",
        "inited": true
    },
    "content": {
        "level": {
            "checked": "绝密",
            "desc": "无、秘密、机密、绝密四选一"
        },
        "businessLevel": {
            "checked": "普通商密",
            "desc": "无、普通商密、核心商密三选一"
        },
        "status": {
            "checked": "国家秘密变更",
            "desc": "密级变更、国家秘密变更二选一"
        },
        "hideStrategy": {
            "flag": true,
            "desc": "是否显示策略配置页面"
        },
        "InterfaceManagement": {
            "flag": false,
            "desc": "是否显示服务接口管理页面"
        },
        "hideIssue": {
            "flag": true,
            "desc": "份号、份数、发文字号选项是否显示"
        },
        "logOutputPath": {
            "value": "/var/log/MJBZRZ",
            "desc": "日志输出路径"
        },
        "databaseContent": {
            "desc": "如果需要手动配置数据库将flag设置成true;user:数据库用户;password:数据库密码;database:数据库仓库;host:数据库安装机器ip;port:数据库端口",
            "flag": false,
            "models": {
                "connection": "mysqlserver",
                "desc": "mysql数据库:mysqlserver;神通数据库:oscard;达梦数据库:dm;人大金仓 kingbase"
            },
            "user": "root",
            "password": "root",
            "database": "clpdserver",
            "host": "127.0.0.1",
            "port": 1300
        },
        "publicSecurityLink": {
            "flag": false,
            "sm4key": "",
            "desc": "公安部级联注册配置开关"
        },
        "upgradeBackup": {
            "excludeBackupTables": "sqlite_sequence,dictionary,dictionary_key,perm,role",
            "desc": "单机版升级数据库迁移配置"
        },
        "documentationPort": {
            "desc": "clientIp:文档服务器ip,clientPort:客户端界面连接文档的接口;serverPort:文档自身启动的端口;proxyServer:代理服务器;proxyBypassList:不通过代理服务器的端口",
            "flag": false,
            "clientIp": "http://132.3.0.2",
            "clientPort": "11259",
            "proxyServer": "--proxy-server='127.0.0.1:12590'",
            "proxyBypassList": "--proxy-bypass-list='ws://132.3.0.2:11259;127.0.0.1:10081;127.0.0.1:10080;127.0.0.1:12570;127.0.0.1:1257'",
            "serverPort": "1259"
        }
    }
};