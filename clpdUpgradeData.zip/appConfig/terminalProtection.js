module.exports = {
    "id": "terminalProtection",
    "meta": {
        "version": "1.0",
        "createdTime": "2019-06-12",
        "name": "终端保护",
        "fileName": "client/terminalProtection.js",
        "inited": true
    },
    "content": {
        "selfProtection": {
            "runMode": 0,
            "processProtected": {
                "itemList": [
                    {
                        "name": ""
                    },
                    {
                        "name": ""
                    },
                    {
                        "name": ""
                    },
                    {
                        "name": ""
                    },
                    {
                        "name": ""
                    },
                    {
                        "name": ""
                    }
                ]
            },
            "directoryProtected": {
                "itemList": [
                    {
                        "path": ""
                    },
                    {
                        "path": ""
                    }
                ],
                "exceptionProcesses": [
                    {
                        "name": ""
                    },
                    {
                        "name": ""
                    },
                    {
                        "name": ""
                    },
                    {
                        "name": ""
                    },
                    {
                        "name": ""
                    },
                    {
                        "name": ""
                    }
                ]
            },
            "serviceProtected": {
                "itemList": [
                    {
                        "name": ""
                    },
                    {
                        "name": ""
                    }
                ]
            }
        }
    }
};