module.exports = {
    "id": "logStrategy",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-07-12",
        "name": "日志开关",
        "fileName": "client/logStrategy.js",
        "inited": true
    },
    "content": {
        "switch": {
            "disabled": false,
            "items": [
                {
                    "id": "17",
                    "value": "涉密文件操作日志",
                    "checked": true,
                    "items": [
                        {
                            "id": "1",
                            "value": "生成",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "2",
                            "value": "绑定",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "3",
                            "value": "读取",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "4",
                            "value": "新建",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "5",
                            "value": "复制",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "6",
                            "value": "修改",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "7",
                            "value": "编辑",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "8",
                            "value": "删除",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "9",
                            "value": "另存为",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "11",
                            "value": "打印",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "12",
                            "value": "合并",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "13",
                            "value": "转换",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "14",
                            "value": "重命名",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "15",
                            "value": "打开",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "16",
                            "value": "移动",
                            "type": "17",
                            "checked": true
                        },
                        {
                            "id": "17",
                            "value": "下载",
                            "type": "17",
                            "checked": true
                        }
                    ]
                },
                {
                    "id": "18",
                    "value": "涉密文件内容操作日志",
                    "checked": true,
                    "items": [
                        {
                            "id": "1",
                            "value": "内容复制",
                            "type": "18",
                            "checked": true
                        },
                        {
                            "id": "2",
                            "value": "内容粘贴",
                            "type": "18",
                            "checked": true
                        }
                    ]
                },
                {
                    "id": "19",
                    "value": "清空日志操作",
                    "checked": true
                },
                {
                    "id": "20",
                    "value": "删除日志操作",
                    "checked": true
                }
            ]
        }
    }
};