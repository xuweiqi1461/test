module.exports = {
    "id": "loginMode",
    "meta": {
        "version": "7.0",
        "createdTime": "2017-07-06",
        "name": "登陆方式配置",
        "fileName": "client/loginMode.js",
        "inited": true
    },
    "content": {
        "modifyPw": {
            "desc": "强制修改密码",
            "value": "7",
            "time": "天"
        },
        "lockRule": {
            "desc": "锁定规则",
            "items": [
                {
                    "value": "24",
                    "desc": "时间"
                },
                {
                    "value": "3",
                    "desc": "次数"
                }
            ]
        },
        "lockTime": {
            "desc": "锁定时长",
            "value": "1"
        },
        "defaultPw": {
            "desc": "默认密码",
            "items": [
                {
                    "desc": "默认密码",
                    "password": "Admin12345"
                },
                {
                    "desc": "首次强制修改密码",
                    "checked": false
                }
            ]
        },
        "pwConfig": {
            "desc": "密码至少包含",
            "checked": [
                {
                    "flag": "0",
                    "checked": true,
                    "desc": "数字"
                },
                {
                    "flag": "1",
                    "checked": true,
                    "desc": "大小写字母"
                },
                {
                    "flag": "3",
                    "checked": false,
                    "desc": "特殊符号(仅包含！@ # ￥ % & *)"
                }
            ]
        },
        "pwLong": {
            "desc": "密码长度",
            "value": 10
        },
        "dpwConfig": {
            "desc": "密码至少包含",
            "checked": [
                {
                    "flag": "0",
                    "checked": true,
                    "desc": "数字"
                },
                {
                    "flag": "1",
                    "checked": true,
                    "desc": "大小写字母"
                },
                {
                    "flag": "3",
                    "checked": false,
                    "desc": "特殊符号(仅包含！@ # ￥ % & *)"
                }
            ]
        },
        "dpwLong": {
            "desc": "密码长度",
            "value": 10
        },
        "sysLogin": {
            "desc": "管理员登录",
            "item": [
                {
                    "ipStart": "",
                    "ipEnd": "",
                    "ip1": "",
                    "ip2": "",
                    "ip3": "",
                    "ip4": "",
                    "ip5": ""
                }
            ]
        },
        "offlineLoginType": {
            "desc": "离线登录",
            "value": true
        },
        "securityAndIssuance": {
            "desc": "直接定密与签发",
            "enabled": false,
            "value": false
        }
    },
    "name": "登陆方式配置"
};