module.exports = {
    "id": "userManagement",
    "meta": {
        "version": "1.0",
        "createdTime": "2019-06-12",
        "name": "用户管理",
        "fileName": "client/userManagement.js",
        "inited": true
    },
    "content": {
        "login": {
            "flag": false,
            "desc": "管理员用户是否可多终端同时登陆（开关已经作废2024-1-14）"
        },
        "roles": {
            "flag": true,
            "desc": "用户是否可拥有多个系统角色"
        },
        "interface56": {
            "flag": false,
            "base": "id",
            "testRole": "",
            "org": "/l=中国",
            "sys": "/dc=万里红电子文件密级标志管理系统（涉密专用计算平台版）V 1.0",
            "roles": [
                {
                    "id": "anquanshenjiyuan",
                    "name": "安全审计员",
                    "type": 0
                },
                {
                    "id": "baomiguanliyuan",
                    "name": "安全保密管理员",
                    "type": 0
                },
                {
                    "id": "xitongguanliyuan",
                    "name": "系统管理员",
                    "type": 0
                },
                {
                    "id": "qianfaren",
                    "name": "文件签发人",
                    "type": 1
                },
                {
                    "id": "qicaoren",
                    "name": "文件起草人",
                    "type": 1
                },
                {
                    "id": "shenheren",
                    "name": "审核人",
                    "type": 1
                },
                {
                    "id": "shiyongrenyuan",
                    "name": "使用人员",
                    "type": 1
                },
                {
                    "id": "zerenren",
                    "name": "定密责任人",
                    "type": 1
                },
                {
                    "id": "zhuanhuanzerenren",
                    "name": "密级标志转换责任人",
                    "type": 1
                }
            ],
            "modeSwitch": true
        },
        "syncbjkw": {
            "flag": false,
            "desc": "科委ukey登录开关",
            "modeSwitch": true
        },
        "syncHaorun": {
            "flag": false,
            "desc": "昊润开关",
            "clientId": "",
            "clientSecret": "",
            "tokenUrl": "",
            "deptUrl": "",
            "userUrl": "",
            "pageSize": 99999,
            "key": ")O[NB]6,YF}+efca",
            "syncDataCycle": ""
        },
        "syncTianjin": {
            "flag": false,
            "desc": "天津oa开关",
            "tokenUrl": "",
            "allDatasUrl": "",
            "certification": {
                "appid": "16101_10",
                "grantType": "client_credential",
                "idNumber": "120101197707077777",
                "imei": "string",
                "loginFlag": "pc",
                "password": "xjj%40876543",
                "username": "jyy"
            },
            "syncDataCycle": ""
        },
        "syncImmigration": {
            "flag": false,
            "desc": "",
            "method": "get",
            "url": "",
            "syncDataCycle": ""
        },
        "syncGannan": {
            "flag": false,
            "desc": "甘南开关,登录方式切换(modeSwitch:true)",
            "generatorChallengeUrl": "",
            "getsignandtokenreqUrl": "",
            "verifyIdentityUrl": "",
            "appserverid": "",
            "modeSwitch": true
        }
    }
};