module.exports = {
    "id": "decryptStrategy",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-07-12",
        "name": "解密和许可证到期提醒",
        "fileName": "client/decryptStrategy.js",
        "inited": true
    },
    "content": {
        "days": {
            "desc": "解密提醒是否开启与提前n天提醒",
            "disabled": false,
            "value": "90"
        },
        "licDay": {
            "desc": "许可证到期提醒是否开启与提前n天提醒",
            "disabled": false,
            "value": "1"
        }
    }
};