module.exports = {
    "id": "redirector",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-06-20",
        "name": "透明加解标策略",
        "fileName": "client/redirector.js",
        "inited": true
    },
    "content": {
        "os": {
            "win32": {
                "runtime": {
                    "disabled": false
                },
                "isEnableHashVerify": false,
                "msgPipeName": "clpdpipe",
                "logFilePath": "%TEMP%\\clpdlog",
                "trustProcessList": {
                    "ignoreGlobPaths": [
                        "*.dll",
                        "*.exe",
                        "*localhost*",
                        "*\\Windows\\*",
                        "*\\Program Files*",
                        "*\\AppData\\Roaming*",
                        "*\\AppData\\LocalLow*",
                        "*\\AppData\\Local\\Packages*",
                        "*\\AppData\\Local\\Microsoft*",
                        "*\\programdata*",
                        "*\\$recycle*",
                        "*\\recycler\\*",
                        "*\\Application Data\\*",
                        "*\\Temporary Internet Files\\*",
                        "*\\mup\\*",
                        "*\\ocls\\lanmanredirector*",
                        "*\\lanmanredirector*",
                        "*\\ocls\\mup*"
                    ],
                    "ignoreLogPaths": [
                        "*.tmp",
                        "*~$*",
                        "*.LINK",
                        "*\\??????00",
                        "*\\appdata\\local\\temp\\*",
                        "*\\Local Settings\\*",
                        "*\\LOCALS~1\\*"
                    ],
                    "processList": [
                        {
                            "matchGlobPaths": [
                                "*.docx",
                                "*.doc",
                                "*.tmp",
                                "*.rtf",
                                "*.txt",
                                "*.xml",
                                "*.pdf",
                                "*.xps",
                                "*.docm",
                                "*.dot",
                                "*.dotm",
                                "*.dotx",
                                "*.odt",
                                "*.htm",
                                "*.ht_",
                                "*.mht",
                                "*.mh_",
                                "*.html",
                                "*.htm_",
                                "*.mhtml",
                                "*.mhtm_"
                            ],
                            "ignoreGlobPaths": [
                                "*~$*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "winword.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.xlsx",
                                "*.xls",
                                "*.tmp",
                                "*\\????????",
                                "*.txt",
                                "*.csv",
                                "*.prn",
                                "*.pdf",
                                "*.xps",
                                "*.xml",
                                "*.dif",
                                "*.slk",
                                "*.ods",
                                "*.xltx",
                                "*.xlt",
                                "*.xltm",
                                "*.xlsm",
                                "*.xlsb",
                                "*.mht",
                                "*.mh_",
                                "*.mhtml",
                                "*.mhtm_",
                                "*.htm",
                                "*.ht_",
                                "*.html",
                                "*.htm_"
                            ],
                            "ignoreGlobPaths": [
                                "*~$*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "excel.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pptx",
                                "*.ppt",
                                "*.tmp",
                                "*.pdf",
                                "*.xps",
                                "*.xml",
                                "*.odp",
                                "*.pot",
                                "*.potx",
                                "*.potm",
                                "*.pps",
                                "*.ppsx",
                                "*.ppsm",
                                "*.pptm",
                                "*.thmx"
                            ],
                            "ignoreGlobPaths": [
                                "*~$*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "powerpnt.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.docx",
                                "*.doc",
                                "*.wps",
                                "*.tmp",
                                "*.rtf",
                                "*.txt",
                                "*.xml",
                                "*.pdf",
                                "*.docm",
                                "*.htm",
                                "*.html",
                                "*.mht",
                                "*.mhtml",
                                "*.uof",
                                "*.wpt",
                                "*.dot",
                                "*.dotx"
                            ],
                            "ignoreGlobPaths": [
                                "*~$*",
                                "*\\appdata\\local\\temp\\*.tmp"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "wps.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.xlsx",
                                "*.xls",
                                "*.et",
                                "*.tmp",
                                "*.pdf",
                                "*.txt",
                                "*.csv",
                                "*.prn",
                                "*.xml",
                                "*.dif",
                                "*.dbf",
                                "*.xlsm",
                                "*.htm",
                                "*.html",
                                "*.mht",
                                "*.mhtml",
                                "*.uof"
                            ],
                            "ignoreGlobPaths": [
                                "*~$*",
                                "*\\appdata\\local\\temp\\*.tmp"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "et.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pptx",
                                "*.ppt",
                                "*.dps",
                                "*.tmp",
                                "*.pdf",
                                "*.pps",
                                "*.ppsm",
                                "*.ppsx",
                                "*.pptm",
                                "*.uof",
                                "*.pot",
                                "*.dpt"
                            ],
                            "ignoreGlobPaths": [
                                "*~$*",
                                "*\\appdata\\local\\temp\\*.tmp"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "wpp.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.docx",
                                "*.doc",
                                "*.dot",
                                "*.dotx",
                                "*.eid",
                                "*.eit",
                                "*.txt",
                                "*.rtf",
                                "*.html",
                                "*.htm",
                                "*.xlsx",
                                "*.xls",
                                "*.xltx",
                                "*.xlt",
                                "*.eis",
                                "*.csv",
                                "*.dbf",
                                "*.pptx",
                                "*.ppt",
                                "*.pps",
                                "*.ppsx",
                                "*.potx",
                                "*.pot",
                                "*.eip",
                                "*.ofd",
                                "*.uop",
                                "*.uof",
                                "*.uot",
                                "*.uos",
                                "*.eio",
                                "*.wpt",
                                "*.xml",
                                "*.dpt",
                                "*.wps",
                                "*.et",
                                "*.dps"
                            ],
                            "ignoreGlobPaths": [
                                "*~$*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "Yozo_Office.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.docx",
                                "*.doc",
                                "*.dot",
                                "*.dotx",
                                "*.eid",
                                "*.eit",
                                "*.txt",
                                "*.rtf",
                                "*.html",
                                "*.htm",
                                "*.wpt",
                                "*.xml",
                                "*.uof",
                                "*.uot",
                                "*.wps"
                            ],
                            "ignoreGlobPaths": [
                                "*~$*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "Yozo_Writer.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.xlsx",
                                "*.xls",
                                "*.xltx",
                                "*.xlt",
                                "*.eis",
                                "*.html",
                                "*.htm",
                                "*.csv",
                                "*.dbf",
                                "*.uos",
                                "*.et"
                            ],
                            "ignoreGlobPaths": [
                                "*~$*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "Yozo_Calc.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pptx",
                                "*.ppt",
                                "*.pps",
                                "*.ppsx",
                                "*.potx",
                                "*.pot",
                                "*.eip",
                                "*.html",
                                "*.htm",
                                "*.dpt",
                                "*.uop",
                                "*.dps"
                            ],
                            "ignoreGlobPaths": [
                                "*~$*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "Yozo_Impress.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.jpg",
                                "*.jpeg",
                                "*.png",
                                "*.bmp",
                                "*.tif",
                                "*.gif",
                                "*.tiff"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "mspaint.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.txt",
                                "*.rtf"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "notepad.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.txt",
                                "*.rtf"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "wordpad.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pdf"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "browser_broker.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pdf"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "pdfreflow.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pdf"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "foxitreader.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pdf"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "foxitphantompdf.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.ofd",
                                "*.pdf",
                                "*.sef"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "suwellreader.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.rar",
                                "*.zip",
                                "*.7z",
                                "*.tmp",
                                "*.zip.*",
                                "*.7z.*"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "360zip.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.rar",
                                "*.zip",
                                "*.zipx",
                                "*.z??",
                                "*.zx??"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "winzip64.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.rar",
                                "*.zip",
                                "*.zipx",
                                "*.z??",
                                "*.zx??"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "winzip32.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.rar",
                                "*.zip",
                                "*.7z",
                                "*.z??",
                                "*.part*",
                                "*__rar_*.*",
                                "*__rzi_*.*"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "winrar.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.rar",
                                "*.zip",
                                "*.7z",
                                "*.tmp",
                                "*.z??",
                                "*.7z.*"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "haozip.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.rar",
                                "*.zip",
                                "*.7z",
                                "*.tmp",
                                "*.zip.*",
                                "*.7z.*"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "7zfm.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.rar",
                                "*.zip",
                                "*.7z",
                                "*.tmp",
                                "*.zip.*",
                                "*.7z.*"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "7zg.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.xps",
                                "*.oxps"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "xpsrchvw.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.avi",
                                "*.mp4",
                                "*.mkv",
                                "*.wmv",
                                "*.wav",
                                "*.mpeg",
                                "*.mpg",
                                "*.mp3",
                                "*.wma",
                                "*.aac",
                                "*.ape",
                                "*.3gp"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "wmplayer.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.avi",
                                "*.mp4",
                                "*.wmv",
                                "*.rmvb"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "xmp.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.avi",
                                "*.mp4",
                                "*.wmv",
                                "*.wav",
                                "*.mp3",
                                "*.wma",
                                "*.aac",
                                "*.ogg"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "baofengplatform.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.avi",
                                "*.mp4",
                                "*.wmv",
                                "*.wav",
                                "*.mp3",
                                "*.wma",
                                "*.acc",
                                "*.ogg",
                                "*.aac",
                                "*.rmvb",
                                "*.ape",
                                "*.3gp"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "stormplayer.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.avi",
                                "*.mp4",
                                "*.wmv",
                                "*.wav",
                                "*.mp3",
                                "*.wma",
                                "*.acc",
                                "*.ogg",
                                "*.aac",
                                "*.rmvb",
                                "*.ape",
                                "*.3gp"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "stormplayer9.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.avi",
                                "*.mp4",
                                "*.wmv",
                                "*.rmvb",
                                "*.3gp",
                                "*.mkv",
                                "*.mpeg",
                                "*.rm"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "geeplayer.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.wav",
                                "*.mp3",
                                "*.mp4",
                                "*.wma",
                                "*.aac",
                                "*.ogg"
                            ],
                            "ignoreGlobPaths": [
                                "*\\appdata\\local\\temp\\*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "kugou.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.wav",
                                "*.mp3",
                                "*.wma"
                            ],
                            "ignoreGlobPaths": [
                                "*\\appdata\\local\\kwmusic\\*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "kwmusic.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.wav",
                                "*.mp3",
                                "*.wma"
                            ],
                            "ignoreGlobPaths": [
                                "*\\appdata\\local\\kwmusic\\*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "kwservice.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.mp3",
                                "*.wma",
                                "*.wav",
                                "*.aac",
                                "*.ogg",
                                "*.ape"
                            ],
                            "ignoreGlobPaths": [
                                "*\\appdata\\local\\netease\\cloudmusic\\*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "cloudmusic.exe"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.prt.*",
                                "*.asm.*"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "xtop.exe"
                            }
                        }
                    ]
                }
            },
            "linux": {
                "runtime": {
                    "disabled": false
                },
                "isEnableHashVerify": false,
                "msgPipeCommonName": "%CLPD_NAMEDPIPE_FILE%",
                "msgPipeLogName": "%CLPD_LOG_NAMEDPIPE_FILE%",
                "logFilePath": "%CLPD_LOG_ROOT%",
                "trustProcessList": {
                    "ignoreGlobPaths": [],
                    "ignoreLogPaths": [],
                    "processList": [
                        {
                            "matchGlobPaths": [
                                "*.doc",
                                "*.docx",
                                "*.wps",
                                "*.txt",
                                "*.htm",
                                "*.html",
                                "*.mhtml",
                                "*.rtf",
                                "*.xml",
                                "*.uot",
                                "*.uof",
                                "*.wpt",
                                "*.dot",
                                "*.dotx"
                            ],
                            "ignoreGlobPaths": [
                                "*/.~*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "16",
                                "imageName": "wps"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.xls",
                                "*.xlsx",
                                "*.et",
                                "*.ett",
                                "*.csv",
                                "*.dbf",
                                "*.dif",
                                "*.xlsm",
                                "*.html",
                                "*.mhtml",
                                "*.txt",
                                "*.xlt",
                                "*.xltx",
                                "*.xml",
                                "*.uof",
                                "*.uos"
                            ],
                            "ignoreGlobPaths": [
                                "*/.~*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "32",
                                "imageName": "et"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.ppt",
                                "*.pptx",
                                "*.dps",
                                "*.pps",
                                "*.ppsm",
                                "*.ppsx",
                                "*.uof",
                                "*.uop",
                                "*.pot",
                                "*.potx",
                                "*.dpt"
                            ],
                            "ignoreGlobPaths": [
                                "*/.~*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "48",
                                "imageName": "wpp"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pdf"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "wpspdf"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.docx",
                                "*.doc",
                                "*.dot",
                                "*.dotx",
                                "*.eid",
                                "*.eit",
                                "*.txt",
                                "*.rtf",
                                "*.html",
                                "*.htm",
                                "*.xlsx",
                                "*.xls",
                                "*.xltx",
                                "*.xlt",
                                "*.eis",
                                "*.csv",
                                "*.dbf",
                                "*.pptx",
                                "*.ppt",
                                "*.pps",
                                "*.ppsx",
                                "*.pdf",
                                "*.potx",
                                "*.pot",
                                "*.eip",
                                "*.ofd",
                                "*.uop",
                                "*.uof",
                                "*.uot",
                                "*.uos",
                                "*.eio",
                                "*.wpt",
                                "*.xml",
                                "*.dpt",
                                "*.wps",
                                "*.et",
                                "*.dps"
                            ],
                            "ignoreGlobPaths": [
                                "*/Yozo_Officelog.txt"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "64",
                                "imageName": "Yozo_Office.bin"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.docx",
                                "*.doc",
                                "*.dot",
                                "*.dotx",
                                "*.eid",
                                "*.eit",
                                "*.txt",
                                "*.rtf",
                                "*.html",
                                "*.htm",
                                "*.wpt",
                                "*.xml",
                                "*.uof",
                                "*.uot",
                                "*.wps"
                            ],
                            "ignoreGlobPaths": [
                                "*/Yozo_Officelog.txt"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "80",
                                "imageName": "Yozo_Writer.bin"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.xlsx",
                                "*.xls",
                                "*.xltx",
                                "*.xlt",
                                "*.eis",
                                "*.html",
                                "*.htm",
                                "*.csv",
                                "*.dbf",
                                "*.uos",
                                "*.et"
                            ],
                            "ignoreGlobPaths": [
                                "*/Yozo_Officelog.txt"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "96",
                                "imageName": "Yozo_Calc.bin"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pptx",
                                "*.ppt",
                                "*.pps",
                                "*.ppsx",
                                "*.potx",
                                "*.pot",
                                "*.eip",
                                "*.html",
                                "*.htm",
                                "*.dpt",
                                "*.uop",
                                "*.dps"
                            ],
                            "ignoreGlobPaths": [
                                "*/Yozo_Officelog.txt"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "112",
                                "imageName": "Yozo_Impress.bin"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.ofd",
                                "*.pdf"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "xReader"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.txt",
                                "*.rtf",
                                "*.goutputstream-*"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "gedit"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.txt",
                                "*.rtf",
                                "*.goutputstream-*"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "pluma"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.mp4",
                                "*.rmvb",
                                "*.avi",
                                "*.wmv",
                                "*.wav",
                                "*.aac",
                                "*.mp3",
                                "*.wma",
                                "*.ogg",
                                "*.mkv",
                                "*.mpeg",
                                "*.rm",
                                "*.3gp",
                                "*.mpg"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "smplayer"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.mp4",
                                "*.rmvb",
                                "*.avi",
                                "*.wmv",
                                "*.wav",
                                "*.aac",
                                "*.mp3",
                                "*.wma",
                                "*.ogg",
                                "*.mkv",
                                "*.mpeg",
                                "*.rm",
                                "*.3gp",
                                "*.mpg"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "mplayer"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.mp4",
                                "*.rmvb",
                                "*.avi",
                                "*.wmv",
                                "*.wav",
                                "*.aac",
                                "*.mp3",
                                "*.wma",
                                "*.ogg",
                                "*.mkv",
                                "*.mpeg",
                                "*.rm",
                                "*.3gp",
                                "*.mpg"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "qaxplayer-stable"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pdf"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "foxitreader"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pdf",
                                "*.ofd"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "SuwellReader"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pdf",
                                "*.ofd"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "DianjuReader"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pdf",
                                "*.ofd"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "FoxitOfficeSuite"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pdf",
                                "*.ofd",
                                "*.sep",
                                "*.gd"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "surSenReader"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.sep",
                                "*.gd"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "sep2ofd"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.mp4",
                                "*.mp3",
                                "*.avi",
                                "*.wmv",
                                "*.wav",
                                "*.aac",
                                "*.wma",
                                "*.ogg",
                                "*.rmvb",
                                "*.mkv",
                                "*.mpeg",
                                "*.rm",
                                "*.3gp",
                                "*.mpg"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "totem"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.mp4",
                                "*.mp3",
                                "*.avi",
                                "*.wmv",
                                "*.wav",
                                "*.aac",
                                "*.wma",
                                "*.ogg",
                                "*.mkv",
                                "*.mpeg",
                                "*.rm",
                                "*.3gp",
                                "*.mpg"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "vlc"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.xcf"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "gimp"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.xcf"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "gimp-2.8"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.gif"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "file-gif-load"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.png"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "file-png"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.jpeg",
                                "*.jpg"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "file-jpeg"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.bmp"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "file-bmp"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.tif",
                                "*.tiff"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "file-tiff-load"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.jpeg",
                                "*.jpg",
                                "*.bmp",
                                "*.tif",
                                "*.png",
                                "*.gif",
                                "*.tiff",
                                "*.goutputstream-*"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "eom"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.jpeg",
                                "*.jpg",
                                "*.bmp",
                                "*.tif",
                                "*.png",
                                "*.gif",
                                "*.tiff"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "gthumb"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.mp3",
                                "*.wav",
                                "*.aac",
                                "*.wma",
                                "*.ogg",
                                "*.mp4"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "audacious"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.mp3",
                                "*.mp4",
                                "*.rmvb",
                                "*.avi",
                                "*.wmv",
                                "*.wav",
                                "*.aac",
                                "*.wma",
                                "*.ogg",
                                "*.mkv",
                                "*.mpeg",
                                "*.rm",
                                "*.3gp",
                                "*.mpg"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "mguess.bin"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pdf",
                                "*.tif"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "evince"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.pdf"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "atril"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.jpeg",
                                "*.jpg",
                                "*.bmp",
                                "*.tif",
                                "*.png",
                                "*.gif",
                                "*.tiff"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "shotwell"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.jpeg",
                                "*.jpg",
                                "*.bmp",
                                "*.tif",
                                "*.png",
                                "*.gif",
                                "*.tiff"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "gpicview"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.mp4",
                                "*.rmvb",
                                "*.avi",
                                "*.wmv",
                                "*.wav",
                                "*.aac",
                                "*.mp3",
                                "*.wma",
                                "*.ogg",
                                "*.mkv",
                                "*.mpeg",
                                "*.rm",
                                "*.3gp",
                                "*.mpg"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "mpv"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.jpeg",
                                "*.jpg",
                                "*.bmp",
                                "*.tif",
                                "*.png",
                                "*.gif",
                                "*.tiff"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "eog"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.jpeg",
                                "*.jpg",
                                "*.bmp",
                                "*.png",
                                "*.gif",
                                "*.tiff"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "cdos-picturebrowser"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.mp3",
                                "*.wav",
                                "*.aac",
                                "*.wma",
                                "*.ape",
                                "*.mp4"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "rhythmbox"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.mp3",
                                "*.wav",
                                "*.aac",
                                "*.wma",
                                "*.ogg",
                                "*.ape",
                                "*.mp4"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "rhythmbox-metadata"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.tar",
                                "*.tar.gz",
                                "*.tar.xz",
                                "*.tar.bz2",
                                "*.tar.lzma",
                                "*.tar.lzo"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "tar"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.gz"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "gzip"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.7z",
                                "*.zip",
                                "*.exe",
                                "*.cbz",
                                "*.iso",
                                "*.rar"
                            ],
                            "ignoreGlobPaths": [
                                "*/.fr-*/*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "7z"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.bz2"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "bzip2"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.tar.xz",
                                "*.tar.lzma"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "xz"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.ar"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "ar"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.jar",
                                "*.zip"
                            ],
                            "ignoreGlobPaths": [
                                "*/.fr-*/*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "zip"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.ar"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "x86_64-linux-gnu-ar"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.ar"
                            ],
                            "ignoreGlobPaths": [
                                "*/.fr-*/*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "mips64el-linux-gnu-ar"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.ar"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "aarch64-linux-gnu-ar"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.tar.7z",
                                "*.zip",
                                "*.7z",
                                "*.7z.tmp",
                                "*.zip.tmp"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "7za"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.7z",
                                "*.exe",
                                "*.cbz",
                                "*.zip",
                                "*.jar",
                                "*.ear",
                                "*.cpio",
                                "*.iso",
                                "*.rar",
                                "*.tar",
                                "*.tar.7z",
                                "*.tar.bz2",
                                "*.tar.gz",
                                "*.tar.lzma",
                                "*.gz",
                                "*.tar.lz",
                                "*.lzma",
                                "*.tar.xz",
                                "*.tar.Z",
                                "*.war",
                                "*.cbr"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "file-compress"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.7z",
                                "*.exe",
                                "*.cbz",
                                "*.zip",
                                "*.jar",
                                "*.ear",
                                "*.cpio",
                                "*.iso",
                                "*.rar",
                                "*.tar",
                                "*.tar.7z",
                                "*.tar.bz2",
                                "*.tar.gz",
                                "*.tar.lzma",
                                "*.gz",
                                "*.tar.lz",
                                "*.lzma",
                                "*.tar.xz",
                                "*.tar.Z",
                                "*.war"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "2",
                                "imageName": "dash"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.zip",
                                "*.jar",
                                "*.ear",
                                "*.war",
                                "*.cbz"
                            ],
                            "ignoreGlobPaths": [
                                "*/.fr-*/*"
                            ],
                            "process": {
                                "hash": "",
                                "controlMode": "1",
                                "imageName": "unzip"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.rar",
                                "*.cbr"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "rar"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.rar",
                                "*.cbr"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "unrar"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.rar",
                                "*.cbr"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "unrar-nonfree"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.tar.lzma"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "lzmp"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.tar.lzo"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "lzop"
                            }
                        },
                        {
                            "matchGlobPaths": [
                                "*.lzma",
                                "*.gz",
                                "*.xz",
                                "*.lz"
                            ],
                            "ignoreGlobPaths": [],
                            "process": {
                                "hash": "",
                                "controlMode": "0",
                                "imageName": "cp"
                            }
                        }
                    ]
                }
            }
        }
    }
};