module.exports = {
    "id": "reviewStrategy",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-07-12",
        "name": "审核流程",
        "fileName": "client/reviewStrategy.js",
        "inited": true
    },
    "content": {
        "switch": {
            "disabled": true,
            "items": [
                {
                    "id": "1",
                    "value": "正式定密流程",
                    "flowObj": {
                        "desc": "审核开关是否开启",
                        "checked": false
                    },
                    "reviewObj": {
                        "desc": "审核人是否为必填项",
                        "checked": false
                    },
                    "noReviewReason": {
                        "desc": "是否填写无审核人原因",
                        "checked": false
                    }
                },
                {
                    "id": "2",
                    "value": "密级变更流程",
                    "flowObj": {
                        "desc": "审核开关是否开启",
                        "checked": false
                    },
                    "reviewObj": {
                        "desc": "审核人是否为必填项",
                        "checked": false
                    },
                    "noReviewReason": {
                        "desc": "是否填写无审核人原因",
                        "checked": false
                    }
                },
                {
                    "id": "3",
                    "value": "文件签发流程",
                    "flowObj": {
                        "desc": "审核开关是否开启",
                        "checked": false
                    },
                    "reviewObj": {
                        "desc": "审核人是否为必填项",
                        "checked": false
                    },
                    "noReviewReason": {
                        "desc": "是否填写无审核人原因",
                        "checked": false
                    }
                },
                {
                    "id": "4",
                    "value": "文件解密流程",
                    "flowObj": {
                        "desc": "审核开关是否开启",
                        "checked": false
                    },
                    "reviewObj": {
                        "desc": "审核人是否为必填项",
                        "checked": false
                    },
                    "noReviewReason": {
                        "desc": "是否填写无审核人原因",
                        "checked": false
                    }
                },
                {
                    "id": "5",
                    "value": "标志解除流程",
                    "flowObj": {
                        "desc": "审核开关是否开启",
                        "checked": false
                    },
                    "reviewObj": {
                        "desc": "审核人是否为必填项",
                        "checked": false
                    },
                    "noReviewReason": {
                        "desc": "是否填写无审核人原因",
                        "checked": false
                    }
                },
                {
                    "id": "8",
                    "value": "文件签出流程",
                    "flowObj": {
                        "desc": "审核开关是否开启",
                        "checked": false
                    },
                    "reviewObj": {
                        "desc": "审核人是否为必填项",
                        "checked": false
                    },
                    "noReviewReason": {
                        "desc": "是否填写无审核人原因",
                        "checked": false
                    }
                },
                {
                    "id": "9",
                    "value": "文件签入流程",
                    "flowObj": {
                        "desc": "审核开关是否开启",
                        "checked": false
                    },
                    "reviewObj": {
                        "desc": "审核人是否为必填项",
                        "checked": false
                    },
                    "noReviewReason": {
                        "desc": "是否填写无审核人原因",
                        "checked": false
                    }
                }
            ]
        }
    }
};