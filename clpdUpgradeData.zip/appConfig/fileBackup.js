module.exports = {
    "id": "fileBackup",
    "meta": {
        "name": "文件备份策略模版",
        "fileName": "client/fileBackup.js",
        "inited": true
    },
    "content": {
        "fileBackup": {
            "enable": 1,
            "reposition": {
                "path": "",
                "status": 0
            },
            "restoreMethod": 1,
            "msgPipeName": "/opt/MJBZGL/MJBZGL/WLH/CLIENT/GN_ZYGLQ/CLPD_NAMEDPIPE",
            "mountDirName": ".WLH",
            "ignorePaths": [
                "*.tmp",
                "*~$*",
                "*.LINK",
                "*\\??????00",
                "*\\appdata\\local\\temp\\*",
                "*\\Local Settings\\*",
                "*\\LOCALS~1\\*",
                "*/.wlhclpdclienttemp/*"
            ],
            "matchPaths": [],
            "backupExePath": "",
            "clearItem": []
        }
    }
};