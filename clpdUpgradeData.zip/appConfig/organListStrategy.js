module.exports = {
    "id": "organListStrategy",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-07-12",
        "name": "树缓存",
        "fileName": "client/organListStrategy.js",
        "inited": true
    },
    "content": {
        "organList": [
            {
                "id": "test",
                "pId": null,
                "name": "组织结构管理",
                "isParent": "true",
                "sortWeight": 1
            },
            {
                "id": "weifenzu",
                "pId": "test",
                "name": "未分组",
                "isParent": "true",
                "sortWeight": 2
            },
            {
                "id": "anquanbaomiguanliyuan",
                "pId": "test",
                "name": "secadmin",
                "isHuman": true
            },
            {
                "id": "anquanshenjiyuan",
                "pId": "test",
                "name": "secauditor",
                "isHuman": true
            },
            {
                "id": "xitongguanliyuan",
                "pId": "test",
                "name": "sysadmin",
                "isHuman": true
            },
            {
                "id": "23b9e3b0-bab2-4aad-940f-88b33b64f279",
                "pId": "test",
                "name": "q",
                "isHuman": true
            }
        ]
    }
};