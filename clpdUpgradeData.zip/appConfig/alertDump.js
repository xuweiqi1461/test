module.exports = {
    "id": "alertDump",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-09-22",
        "name": "警戒转存配置",
        "fileName": "client/alertDump.js",
        "inited": true
    },
    "content": {
        "storeLetterDesc": "日志存储磁盘",
        "storeLetter": "C",
        "binPathDesc": "服务器数据库安装目录",
        "binPath": "",
        "dumpLocationDesc": "备份数据库目录,将数据库备份到此目录",
        "dumpLocation": "",
        "runtime": {
            "disabled": true
        },
        "control": {
            "alertValueDesc": "占用磁盘的百分比达到此值时会提醒",
            "alertValue": "70",
            "promptFlagDesc": "是否消息通知系统管理员",
            "promptFlag": true,
            "autoDumpDesc": "是否自动转存",
            "autoDump": true
        }
    }
};