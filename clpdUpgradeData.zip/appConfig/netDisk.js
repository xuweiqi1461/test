module.exports = {
    "id": "netDisk",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-06-20",
        "name": "网络磁盘配置",
        "fileName": "client/netDisk.js",
        "dontMergeConfig": true,
        "ignoreSync": true,
        "inited": true
    },
    "content": {
        "runtime": {
            "disabled": false
        },
        "netdisks": {}
    }
};