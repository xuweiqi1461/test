module.exports = {
    "id": "preclass",
    "meta": {
        "name": "预定密模板",
        "fileName": "client/preclass.js",
        "inited": true
    },
    "content": {
        "level": 21,
        "duration": {
            "period": "999999"
        },
        "status": 50
    }
};