module.exports = {
    "id": "cascadingRegistration",
    "meta": {
        "version": "1.0",
        "createdTime": "2021-08-18",
        "name": "级联注册配置",
        "fileName": "client/cascadingRegistration.js",
        "inited": true
    },
    "content": {
        "guid": {
            "value": "",
            "desc": "系统ID"
        },
        "token": {
            "value": "",
            "desc": "令牌"
        },
        "name": {
            "value": "",
            "desc": "部门名称"
        },
        "region": {
            "value": "",
            "desc": "行政区划编码"
        },
        "factory": {
            "value": "",
            "desc": "厂商编码"
        },
        "serverType": {
            "value": "",
            "desc": "产品类别"
        },
        "serverIp": {
            "value": "",
            "desc": "服务端IP"
        },
        "serverPort": {
            "value": "",
            "desc": "服务端端口"
        },
        "version": {
            "value": "",
            "desc": "服务端版本"
        },
        "defaultUrl": {
            "value": "",
            "desc": "上级节点地址"
        },
        "policyAndVersion": {
            "filetype": -1,
            "file": "",
            "logtype": -1,
            "log": {
                "reportList": []
            },
            "desc": "策略内容和策略版本"
        },
        "getPolicyTime": {
            "time": "",
            "desc": "策略拉取时间"
        }
    }
};