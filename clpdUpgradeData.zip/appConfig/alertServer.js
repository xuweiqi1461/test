module.exports = {
    "id": "alertServer",
    "meta": {
        "version": "1.0",
        "createdTime": "2017-07-06",
        "name": "告警服务配置",
        "fileName": "client/alertServer.js",
        "inited": true
    },
    "content": {
        "alertEmail": {
            "desc": "启用告警邮件服务",
            "checked": true
        },
        "safety": {
            "desc": "安全连接（SSL）",
            "checked": true
        },
        "serverAddress": {
            "desc": "服务器地址",
            "value": ""
        },
        "serverProt": {
            "desc": "端口",
            "value": ""
        },
        "serverAccount": {
            "desc": "发件人邮箱地址",
            "value": ""
        },
        "serverPW": {
            "desc": "发件人邮箱密码",
            "value": ""
        },
        "addresser": {
            "desc": "发送方姓名",
            "value": ""
        },
        "logStorage": {
            "desc": "启用日志存储告警",
            "checked": true
        },
        "logTime": {
            "desc": "检查时间",
            "time": "10:00:00"
        },
        "logVigilance": {
            "desc": "警戒值",
            "value": "70"
        },
        "logAlarmMode": {
            "desc": "告警方式",
            "items": [
                {
                    "id": "0",
                    "value": "消息通知",
                    "checked": true
                },
                {
                    "id": "1",
                    "value": "邮件通知",
                    "checked": false
                }
            ]
        },
        "logAlarmEmail": {
            "desc": "告警邮箱",
            "value": ""
        },
        "fileStore": {
            "desc": "启用文件存储告警",
            "checked": true
        },
        "fileTransfer": {
            "desc": "是否自动转存",
            "checked": true
        },
        "fileTime": {
            "desc": "检查时间",
            "time": "10:00:00"
        },
        "fileOldPosition": {
            "desc": "文件原来存储位置",
            "value": ""
        },
        "fileNowPosition": {
            "desc": "文件现存磁盘位置",
            "value": "./storage"
        },
        "fileTransferPosition": {
            "desc": "转存位置",
            "value": ""
        },
        "fileVigilance": {
            "desc": "警戒值",
            "value": "70"
        },
        "fileAlarmMode": {
            "desc": "告警方式",
            "items": [
                {
                    "id": "0",
                    "value": "消息通知",
                    "checked": true
                },
                {
                    "id": "1",
                    "value": "邮件通知",
                    "checked": false
                }
            ]
        },
        "fileAlarmEmail": {
            "desc": "告警邮箱",
            "value": ""
        },
        "illegalOperation": {
            "desc": "启用违规操作告警",
            "checked": true
        },
        "illegalAlarmMode": {
            "desc": "告警方式",
            "items": [
                {
                    "id": "0",
                    "value": "消息通知",
                    "checked": true
                },
                {
                    "id": "1",
                    "value": "邮件通知",
                    "checked": false
                }
            ]
        },
        "illegalEmail": {
            "desc": "告警邮箱",
            "value": ""
        },
        "logTransfer": {
            "desc": "启用日志转存与告警",
            "checked": true
        },
        "logInterval": {
            "desc": "检查时间",
            "time": "10:00:00"
        },
        "logValue": {
            "desc": "转存触发值",
            "value": "70"
        },
        "logStrategy": {
            "desc": "转存策略",
            "items": [
                {
                    "id": "0",
                    "value": "转存至目标位置并清空日志",
                    "checked": true
                },
                {
                    "id": "1",
                    "desc": "目标位置",
                    "value": ""
                },
                {
                    "id": "2",
                    "desc": "不转存，自动覆盖，只保留最近***日志",
                    "value": "3",
                    "checked": false
                }
            ]
        },
        "logMode": {
            "desc": "告警方式",
            "items": [
                {
                    "id": "0",
                    "value": "消息通知",
                    "checked": true
                },
                {
                    "id": "1",
                    "value": "邮件通知(告警方式)",
                    "checked": false
                }
            ]
        },
        "logEmail": {
            "desc": "告警邮箱",
            "value": ""
        }
    }
};